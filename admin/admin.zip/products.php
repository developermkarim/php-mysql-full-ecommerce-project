<?php
include_once './header.php';
?>
<div class="col-md-10 col-sm-9" id="admin-product">
<div class="admin-content-container">
        <h2 class="admin-heading">All Products</h2>
        <a class="add-new pull-right" href="add_product.php">Add New</a>
      
            <table id="productsTable" class="table table-striped table-hover table-bordered">
                <thead>
                    <th>#</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Image</th>
                    <th>Status</th>
                    <th width="100px">Action</th>
                </thead>
                <tbody>
                   
                    <tr>
                        <td><b></b></td>
                        <td><?php  ?></td>
                        <td><?php  ?></td>
                        <td><?php  ?></td>
                        <td><?php ?></td>
                        <td><?php  ?></td>
                        <td>
                            Lorem ipsum dolor sit.
                        </td>
                        <td>
                            Lorem, ipsum dolor.
                        </td>
                        <td>
                            <a href="edit_product.php?id=<?php  ?>"><i class="fa fa-edit"></i></a>
                            <a class="delete_product" href="javascript:void()" data-id="<?php ?>" data-subcat="<?php  ?>"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
               
                </tbody>
            </table>
       
            <div class="not-found clearfix">!!! No Products Found !!!</div>
        
        <div class="pagination-outer">
      
        </div>
    </div>


    </div>

<?php include './footer.php' ?>